# Wecima Extension

إضافة Wecima لمشاهدة الأفلام والمسلسلات على CloudStream.