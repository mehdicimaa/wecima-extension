
plugins {
    id("cloudstream.plugin") version "1.0.0"
    kotlin("jvm") version "1.7.10"
}
cloudstream {
    language = "ar"
    description = "مشغل wecima لـ CloudStream"
}
